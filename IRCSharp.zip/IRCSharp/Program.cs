﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace IRCSharp
{
    class Settings
    {
        // User information
        private static string nick = "Dev";
        private static string user = "God";
        private static int mode = 0;
        private static string realname = "Packet Delivery Man";
        // Behavior settings
        private static bool autojoin = false;

        public static dynamic Fetch(string setting)
        {
            if (setting == "Nick") { return nick; }
            if (setting == "User") { return user; }
            if (setting == "Mode") { return mode; }
            if (setting == "Realname") { return realname; }
            return null;
        }

        public static dynamic Set(string setting, string value)
        {
            if (setting == "Nick") { nick = value; }
            return value;
        }
    }

    class Parse
    {

        public static Int32 FindNth(Int32 n, string s, string message)
        {
            Int32 x = 0;
            if (message.IndexOf(s) == -1)
            {
                return -1;
            }
            else
            {
                for (int i = 1; i <= n; i++)
                {
                    x = message.IndexOf(s, x + 1);
                }
            }
            return x;
        }

        public static void getLines(string message)
        {
            while (message.IndexOf("\r\n") != -1)
            {
                Int32 f = message.IndexOf("\r\n");
                getParameters(message.Substring(0, f + 2));
                message = message.Remove(0, f + 2);
            }
        }

        public static void getParameters(string message)
        {
            Console.WriteLine("SERVER: {0}", message);
            // Locate Nick, User, Host, Type, and Message Strings
            // Incoming message e.g:
            // :their_nick!user@host.sex.party.com PRIVMSG OUR_NICK :hello my name is, slim anus./r/n
            // : NICK ! USER @ HOST MSGTYPE OUR_NICK :MESSAGE BODY/r/n
            // /r/n indicates a new line.
            string nick = string.Empty;
            string user = string.Empty;
            string host = string.Empty;
            string msgType = string.Empty;
            string parameters = string.Empty;
            Int32 beginPos;
            Int32 endPos;
            Int32 length;
            if (message.IndexOf("!") < message.IndexOf("@") && message.IndexOf("@") < message.IndexOf(" ", FindNth(1, " ", message)))
            {
                // Find Nick
                beginPos = message.IndexOf(":", 0) + 1;
                endPos = message.IndexOf("!", 0) - 2;
                length = beginPos + endPos;
                nick = message.Substring(1, length);
                message = message.Remove(0, length + 1);

                // Find User
                beginPos = message.IndexOf("!", 0);
                endPos = message.IndexOf("@", 0);
                length = beginPos + endPos;
                user = message.Substring(beginPos + 1, length - 1);
                message = message.Remove(beginPos, length);

                // Find Host
                beginPos = message.IndexOf("@", 0) + 1;
                endPos = message.IndexOf(" ", FindNth(1, " ", message));
                length = beginPos + endPos;
                host = message.Substring(1, length - 2);
                message = message.Remove(0, length);

                // Find MsgType
                beginPos = 0;
                endPos = message.IndexOf(" ", FindNth(1, " ", message));
                length = beginPos + endPos;
                msgType = message.Substring(0, length);
                message = message.Remove(0, length);
            }
            else if (message.Contains("PING ") && message.IndexOf("PING ", 0) < message.IndexOf(" ", FindNth(1, " ", message)))
            {
                // PING :unique_string
                // PONG :unique_string
                beginPos = message.IndexOf(":", 0);
                string subString = message.Remove(0, beginPos);
                Connection.Send("PONG " + subString);
            }
        }

    } // End Class Parse
    class Connection
    {
        private static TcpClient s;
        private static byte[] data;
        private static NetworkStream iostream;

        public static void Connect(string host, int port)
        {
            s = new TcpClient(host, port);
            iostream = s.GetStream();
        } //  end connect

        public static void Send(string message)
        {
            Byte[] data = System.Text.Encoding.ASCII.GetBytes(message);
            iostream.Write(data, 0, data.Length);
            Console.WriteLine("<Me> {0}", message);
        } // end send

        public static void Clean()
        {
            iostream.Close();
            s.Close();
        } // end clean

        public static void Listen()
        {
            string receiveData = String.Empty;
            data = new byte[256];
            while (data != null)
            {

                Int32 bytes = iostream.Read(data, 0, data.Length);
                receiveData = System.Text.Encoding.ASCII.GetString(data, 0, data.Length);
                Parse.getLines(receiveData);
                Array.Clear(data, 0, data.Length);
                // Close the stream and socket if we get disconnected
                if (receiveData.Contains("Closing Link"))
                {
                    Clean();
                    break;
                }
                // Connection Registration
                // TEMP looking for :test.environment.server NOTICE * :*** Looking up your hostname...
                // to know we are connected.
                if (receiveData.Contains("Looking up"))
                {
                    // RFC 1459 Section 4.1
                    Send("NICK " + Settings.Fetch("Nick") + "\r\n");
                    /*
                     Command:        USER
                     Parameters:     <username> <mdoe> <unused> <realname>
                     It must be noted that realname parameter must be the last parameter,
                     because it may contain space characters and must be prefixed with a
                     colon (':') to make sure this is recognised as such.
                     */
                    Send("USER " + Settings.Fetch("User") + " " + Settings.Fetch("Mode") + " * :" + Settings.Fetch("Realname") + "\r\n");
                }
            }
        } // End Class Connection
    }

    class Program
    {
        static void Main()
        {
            Connection.Connect("localhost", 6667);
            ThreadStart listenref = new ThreadStart(() => Connection.Listen());
            Thread Listener = new Thread(listenref);
            Listener.Start();
        }

    } // End Class Program

} // End Namespace

